export {default as Decimation} from './plugin.decimation';
export {default as Filler} from './plugin.filler';
export {default as Legend} from './plugin.legend';
export {default as SubTitle} from './plugin.subtitle';
export {default as Title} from './plugin.title';
export {default as Tooltip} from './plugin.tooltip';
